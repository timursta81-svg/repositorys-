const loginView = document.querySelector("#loginView");
const profileView = document.querySelector("#profileView");
const message = document.querySelector("#message");

async function loadProfile() {
  const response = await fetch("/api/profile");
  if (!response.ok) return;
  const user = await response.json();
  showProfile(user);
}

function showProfile(user) {
  loginView.hidden = true;
  profileView.hidden = false;
  document.querySelector("#studentName").textContent = `Студент: ${user.name}`;
  message.textContent = "Вход выполнен успешно.";
}

document.querySelector("#loginForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  message.textContent = "";
  const login = document.querySelector("#login").value.trim();
  const password = document.querySelector("#password").value;

  try {
    const response = await fetch("/api/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ login, password })
    });
    const data = await response.json();
    if (!response.ok) {
      message.textContent = data.message;
      return;
    }
    showProfile(data.user);
  } catch {
    message.textContent = "Не удалось связаться с сервером.";
  }
});

document.querySelector("#logoutButton").addEventListener("click", async () => {
  await fetch("/api/logout", { method: "POST" });
  profileView.hidden = true;
  loginView.hidden = false;
  document.querySelector("#loginForm").reset();
  message.textContent = "Вы вышли из системы.";
});

loadProfile();
