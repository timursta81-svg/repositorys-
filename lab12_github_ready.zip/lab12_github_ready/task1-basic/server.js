require("dotenv").config();
const express = require("express");
const session = require("express-session");
const bcrypt = require("bcryptjs");
const path = require("path");

const app = express();
const PORT = 3001;
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));
app.use(session({
  name: "student.sid",
  secret: process.env.SESSION_SECRET || "development-only-change-me",
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "strict", secure: process.env.NODE_ENV === "production", maxAge: 30 * 60 * 1000 }
}));

const passwordHash = bcrypt.hashSync(process.env.STUDENT_PASSWORD || "student123", 10);

app.post("/api/login", async (req, res) => {
  const { login, password } = req.body || {};
  if (!login || !password) return res.status(400).json({ message: "Заполните логин и пароль." });
  if (login !== "student" || !(await bcrypt.compare(password, passwordHash))) {
    return res.status(401).json({ message: "Неверный логин или пароль." });
  }
  req.session.user = { login: "student", name: "Тестовый студент" };
  res.json({ message: "Вход выполнен.", user: req.session.user });
});

app.get("/api/profile", (req, res) => {
  if (!req.session.user) return res.status(401).json({ message: "Требуется вход." });
  res.json(req.session.user);
});

app.post("/api/logout", (req, res) => {
  req.session.destroy(() => {
    res.clearCookie("student.sid");
    res.json({ message: "Выход выполнен." });
  });
});

app.listen(PORT, () => console.log(`Базовое задание: http://localhost:${PORT}`));
