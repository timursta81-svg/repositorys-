require("dotenv").config();
const express = require("express");
const jwt = require("jsonwebtoken");
const cookieParser = require("cookie-parser");
const bcrypt = require("bcryptjs");
const crypto = require("crypto");
const path = require("path");

const app = express();
const PORT = 3003;
const ACCESS_SECRET = process.env.ACCESS_SECRET;
const REFRESH_SECRET = process.env.REFRESH_SECRET;
if (!ACCESS_SECRET || !REFRESH_SECRET) {
  throw new Error("Укажите ACCESS_SECRET и REFRESH_SECRET в .env");
}
app.use(express.json());
app.use(cookieParser());
app.use(express.static(path.join(__dirname, "public")));

const user = {
  id: 1,
  login: "student",
  hash: bcrypt.hashSync(process.env.STUDENT_PASSWORD || "student123", 10)
};
// Учебное хранилище активного refresh-token: userId -> jti.
const activeRefresh = new Map();

function makeAccessToken() {
  return jwt.sign({ sub: user.id, role: "student" }, ACCESS_SECRET, {
    expiresIn: "2m", algorithm: "HS256", issuer: "lab12", audience: "lab12-client"
  });
}
function makeRefreshToken() {
  const jti = crypto.randomUUID();
  const token = jwt.sign({ sub: user.id, jti }, REFRESH_SECRET, {
    expiresIn: "1d", algorithm: "HS256", issuer: "lab12", audience: "lab12-refresh"
  });
  activeRefresh.set(user.id, jti);
  return token;
}
function setRefreshCookie(res, token) {
  res.cookie("refreshToken", token, {
    httpOnly: true, sameSite: "strict",
    secure: process.env.NODE_ENV === "production",
    path: "/api/refresh", maxAge: 24 * 60 * 60 * 1000
  });
}
function authenticate(req, res, next) {
  const header = req.get("Authorization") || "";
  if (!header.startsWith("Bearer ")) return res.status(401).json({ message: "Access Token отсутствует." });
  try {
    req.auth = jwt.verify(header.slice(7), ACCESS_SECRET, {
      algorithms: ["HS256"], issuer: "lab12", audience: "lab12-client"
    });
    next();
  } catch {
    res.status(401).json({ message: "Access Token недействителен или истёк." });
  }
}

app.post("/api/login", async (req, res) => {
  const { login, password } = req.body || {};
  if (!login || !password) return res.status(400).json({ message: "Заполните все поля." });
  if (login !== user.login || !(await bcrypt.compare(password, user.hash))) {
    return res.status(401).json({ message: "Неверный логин или пароль." });
  }
  const accessToken = makeAccessToken();
  const refreshToken = makeRefreshToken();
  setRefreshCookie(res, refreshToken);
  res.json({ message: "Вход выполнен.", accessToken });
});

app.get("/api/profile", authenticate, (req, res) => {
  if (req.auth.sub !== user.id) return res.status(403).json({ message: "Нет доступа." });
  res.json({ message: "Доступ к защищённому профилю разрешён.", user: user.login });
});

app.post("/api/refresh", (req, res) => {
  const token = req.cookies.refreshToken;
  if (!token) return res.status(401).json({ message: "Refresh Token отсутствует. Войдите снова." });
  try {
    const payload = jwt.verify(token, REFRESH_SECRET, {
      algorithms: ["HS256"], issuer: "lab12", audience: "lab12-refresh"
    });
    if (payload.sub !== user.id || activeRefresh.get(user.id) !== payload.jti) {
      return res.status(401).json({ message: "Refresh Token недействителен или уже использован." });
    }
    const accessToken = makeAccessToken();
    const refreshToken = makeRefreshToken(); // ротация: старый jti заменяется новым
    setRefreshCookie(res, refreshToken);
    res.json({ message: "Токены обновлены.", accessToken });
  } catch {
    res.status(401).json({ message: "Refresh Token истёк или недействителен." });
  }
});

app.post("/api/logout", (req, res) => {
  const token = req.cookies.refreshToken;
  if (token) {
    try {
      const payload = jwt.verify(token, REFRESH_SECRET, {
        algorithms: ["HS256"], issuer: "lab12", audience: "lab12-refresh"
      });
      if (activeRefresh.get(user.id) === payload.jti) activeRefresh.delete(user.id);
    } catch { /* истёкший токен всё равно удаляем из браузера */ }
  }
  res.clearCookie("refreshToken", {
    httpOnly: true, sameSite: "strict",
    secure: process.env.NODE_ENV === "production", path: "/api/refresh"
  });
  res.json({ message: "Выход выполнен. Refresh Token отозван." });
});

app.listen(PORT, () => console.log(`Повышенное задание: http://localhost:${PORT}`));
