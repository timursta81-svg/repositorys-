let accessToken = null;
const loginView = document.querySelector("#loginView");
const profileView = document.querySelector("#profileView");
const message = document.querySelector("#message");

async function requestProfile() {
  const response = await fetch("/api/profile", {
    headers: accessToken ? { Authorization: `Bearer ${accessToken}` } : {}
  });
  const data = await response.json();
  if (response.ok) {
    loginView.hidden = true;
    profileView.hidden = false;
    document.querySelector("#profileInfo").textContent = data.message;
  }
  message.textContent = data.message;
  return response.ok;
}

document.querySelector("#loginForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  const login = document.querySelector("#login").value.trim();
  const password = document.querySelector("#password").value;
  const response = await fetch("/api/login", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ login, password })
  });
  const data = await response.json();
  if (!response.ok) { message.textContent = data.message; return; }
  accessToken = data.accessToken;
  loginView.hidden = true;
  profileView.hidden = false;
  message.textContent = data.message;
});

document.querySelector("#checkButton").addEventListener("click", requestProfile);

document.querySelector("#refreshButton").addEventListener("click", async () => {
  const response = await fetch("/api/refresh", { method: "POST" });
  const data = await response.json();
  if (!response.ok) {
    message.textContent = data.message;
    return;
  }
  accessToken = data.accessToken;
  message.textContent = "Access Token обновлён, Refresh Token ротирован.";
});

document.querySelector("#logoutButton").addEventListener("click", async () => {
  await fetch("/api/logout", { method: "POST" });
  accessToken = null;
  profileView.hidden = true;
  loginView.hidden = false;
  document.querySelector("#loginForm").reset();
  message.textContent = "Вы вышли из системы.";
});
