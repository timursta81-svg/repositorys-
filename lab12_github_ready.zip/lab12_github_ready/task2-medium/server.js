require("dotenv").config();
const express = require("express");
const session = require("express-session");
const bcrypt = require("bcryptjs");
const path = require("path");

const app = express();
const PORT = 3002;
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));
app.use(session({
  name: "roles.sid",
  secret: process.env.SESSION_SECRET || "development-only-change-me",
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "strict", secure: process.env.NODE_ENV === "production", maxAge: 30 * 60 * 1000 }
}));

const users = [
  { id: 1, login: "student", role: "student", name: "Тестовый студент", hash: bcrypt.hashSync(process.env.STUDENT_PASSWORD || "student123", 10) },
  { id: 2, login: "teacher", role: "teacher", name: "Тестовый преподаватель", hash: bcrypt.hashSync(process.env.TEACHER_PASSWORD || "teacher123", 10) }
];

function requireLogin(req, res, next) {
  if (!req.session.user) return res.status(401).json({ message: "Сначала войдите в систему." });
  next();
}
function requireRole(role) {
  return (req, res, next) => {
    if (req.session.user.role !== role) return res.status(403).json({ message: "Доступ запрещён: недостаточно прав." });
    next();
  };
}

app.post("/api/login", async (req, res) => {
  const { login, password } = req.body || {};
  if (!login || !password) return res.status(400).json({ message: "Заполните все поля." });
  const user = users.find(item => item.login === login);
  if (!user || !(await bcrypt.compare(password, user.hash))) return res.status(401).json({ message: "Неверный логин или пароль." });
  req.session.regenerate(err => {
    if (err) return res.status(500).json({ message: "Не удалось создать сессию." });
    req.session.user = { id: user.id, login: user.login, role: user.role, name: user.name };
    res.json({ user: req.session.user, message: "Вход выполнен." });
  });
});

app.get("/api/student", requireLogin, requireRole("student"), (req, res) => {
  res.json({ title: "Кабинет студента", info: "Доступны расписание, занятия и учебные материалы." });
});
app.get("/api/teacher", requireLogin, requireRole("teacher"), (req, res) => {
  res.json({ title: "Кабинет преподавателя", info: "Доступны список студентов и управление занятиями." });
});
app.post("/api/logout", requireLogin, (req, res) => {
  req.session.destroy(() => {
    res.clearCookie("roles.sid");
    res.json({ message: "Вы вышли из системы." });
  });
});

app.listen(PORT, () => console.log(`Среднее задание: http://localhost:${PORT}`));
