const loginView = document.querySelector("#loginView");
const profileView = document.querySelector("#profileView");
const message = document.querySelector("#message");

document.querySelector("#loginForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  const login = document.querySelector("#login").value.trim();
  const password = document.querySelector("#password").value;
  try {
    const response = await fetch("/api/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ login, password })
    });
    const data = await response.json();
    if (!response.ok) { message.textContent = data.message; return; }
    await loadRolePage(data.user.role);
  } catch { message.textContent = "Ошибка соединения с сервером."; }
});

async function loadRolePage(role) {
  const response = await fetch(`/api/${role}`);
  const data = await response.json();
  if (!response.ok) { message.textContent = data.message; return; }
  loginView.hidden = true;
  profileView.hidden = false;
  document.querySelector("#roleTitle").textContent = data.title;
  document.querySelector("#roleInfo").textContent = data.info;
  message.textContent = `Вы вошли как ${role}.`;
}

document.querySelector("#logoutButton").addEventListener("click", async () => {
  await fetch("/api/logout", { method: "POST" });
  profileView.hidden = true;
  loginView.hidden = false;
  document.querySelector("#loginForm").reset();
  message.textContent = "Вы вышли из системы.";
});
